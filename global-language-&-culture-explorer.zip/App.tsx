
import React, { useState, useCallback, useEffect } from 'react';
import { Language, Country, LearningMode, SelectionOptions } from './types';
import { AVAILABLE_LANGUAGES, AVAILABLE_COUNTRIES, AVAILABLE_MODES, API_KEY_ERROR_MESSAGE } from './constants';
import ControlPanel from './components/ControlPanel';
import ContentDisplay from './components/ContentDisplay';
import { generateEducationalContent } from './services/GeminiService';

const App: React.FC = () => {
  const [selections, setSelections] = useState<SelectionOptions>({
    language: AVAILABLE_LANGUAGES[0],
    country: AVAILABLE_COUNTRIES[0],
    mode: AVAILABLE_MODES[0],
  });
  const [generatedContent, setGeneratedContent] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [apiKeyMissing, setApiKeyMissing] = useState<boolean>(false);

  useEffect(() => {
    // Check for API_KEY on initial load
    if (!process.env.API_KEY) {
      setApiKeyMissing(true);
      setError(API_KEY_ERROR_MESSAGE); // Set error message for display
    }
  }, []);

  const handleSelectionChange = useCallback(<K extends keyof SelectionOptions>(
    key: K,
    value: SelectionOptions[K]
  ) => {
    setSelections((prev) => ({ ...prev, [key]: value }));
  }, []);

  const constructPrompt = (currentSelections: SelectionOptions): string => {
    const { language, country, mode } = currentSelections;
    let prompt = `You are an AI language and culture educator. Your student wants to learn about ${country}. All information should be provided in ${language}. The student is interested in ${mode}. `;

    switch (mode) {
      case LearningMode.FACTS:
        prompt += `Please provide 3-5 concise and interesting facts about ${country}.`;
        break;
      case LearningMode.PHRASES:
        let targetLanguage = '';
        if (country === Country.SOUTH_KOREA) targetLanguage = 'Korean';
        else if (country === Country.JAPAN) targetLanguage = 'Japanese';
        else if (country === Country.CHINA) targetLanguage = 'Chinese';
        prompt += `Please provide 3-5 common ${targetLanguage} phrases useful for a beginner. For each phrase, include: 
        1. The phrase in its native script (e.g., Hangul for Korean, Kanji/Hiragana/Katakana for Japanese, Hanzi for Chinese).
        2. A romanized version of the phrase.
        3. The translation of the phrase into ${language}.
        4. A brief explanation of when to use the phrase, also in ${language}.`;
        break;
      case LearningMode.CULTURE:
        prompt += `Please describe 3-5 key cultural highlights or unique traditions of ${country}.`;
        break;
      case LearningMode.QUIZ:
        prompt += `Please create a simple multiple-choice quiz question about ${country}. The question should have one correct answer and two incorrect plausible distractors (labeled A, B, C). Indicate the correct answer clearly. The entire quiz (question, options, answer indication) should be in ${language}.`;
        break;
    }
    prompt += ` Ensure the response is formatted clearly for easy reading.`;
    return prompt;
  };

  const handleGenerateContent = useCallback(async () => {
    if (apiKeyMissing) {
      setError(API_KEY_ERROR_MESSAGE);
      return;
    }

    setIsLoading(true);
    setError(null);
    setGeneratedContent(null);

    const prompt = constructPrompt(selections);
    
    try {
      const content = await generateEducationalContent(prompt);
      setGeneratedContent(content);
    } catch (e: any) {
      setError(e.message || "An unexpected error occurred.");
      setGeneratedContent(null);
    } finally {
      setIsLoading(false);
    }
  }, [selections, apiKeyMissing]);


  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-gray-900 text-slate-100 p-4 md:p-8 flex flex-col items-center">
      <header className="mb-8 text-center">
        <h1 className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-blue-500">
          Global Language & Culture Explorer
        </h1>
        <p className="text-slate-400 mt-2 text-lg">Your AI-powered guide to languages and cultures.</p>
      </header>

      <main className="w-full max-w-5xl grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
        <div className="md:col-span-1">
          <ControlPanel
            selections={selections}
            onSelectionChange={handleSelectionChange}
            onGenerate={handleGenerateContent}
            isLoading={isLoading}
            apiKeyMissing={apiKeyMissing}
          />
        </div>
        <div className="md:col-span-2">
          <ContentDisplay
            content={generatedContent}
            isLoading={isLoading}
            error={error}
            apiKeyMissing={apiKeyMissing}
          />
        </div>
      </main>
      <footer className="mt-12 text-center text-slate-500 text-sm">
        <p>&copy; {new Date().getFullYear()} AI Educator App. Powered by Gemini.</p>
         <p>Note: Ensure `process.env.API_KEY` is set in your environment for AI features to work.</p>
      </footer>
    </div>
  );
};

export default App;
    