
import React from 'react';
import SpinnerIcon from './icons/SpinnerIcon';
import { API_KEY_ERROR_MESSAGE } from '../constants';

interface ContentDisplayProps {
  content: string | null;
  isLoading: boolean;
  error: string | null;
  apiKeyMissing: boolean;
}

const ContentDisplay: React.FC<ContentDisplayProps> = ({ content, isLoading, error, apiKeyMissing }) => {
  if (apiKeyMissing) {
    return (
      <div className="bg-slate-800/70 backdrop-blur-lg p-6 rounded-xl shadow-2xl border border-slate-700 min-h-[200px] flex flex-col justify-center items-center">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-12 h-12 text-yellow-400 mb-4">
          <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m0-10.036A11.959 11.959 0 013.598 6H5.03a8.982 8.982 0 001.502-2.392M12 9v3.75m-3.75 3.75h7.5m-7.5 0a3.75 3.75 0 01-3.75-3.75V8.625c0-1.01.364-1.942 1.004-2.686M12 9v3.75m6-11.25L15.353 4.853A8.96 8.96 0 0012.014 4C9.96 4 8.064 4.722 6.574 6M12 21a8.96 8.96 0 004.926-1.505L15.353 17.647A6 6 0 0112.014 18C9.262 18 7.009 16.195 6.08 13.853m11.84-3.909A3.752 3.752 0 0015.375 9H12m0 0V7.5m6 1.5H9m0 0H7.5m1.5 0c0 .896.364 1.724 1.004 2.314M12 12H9m3 0h3m-3 0V9m3 3V9m0 3h2.25m-2.25 0h-2.25m0 0V9m2.25 3.75V12m0-3V7.5m0 0h-.686A2.25 2.25 0 009.75 9.75V12m0 0V9" />
        </svg>
        <h3 className="text-xl font-semibold text-yellow-400 mb-2">Configuration Needed</h3>
        <p className="text-slate-300 text-center">{API_KEY_ERROR_MESSAGE}</p>
      </div>
    );
  }
  
  if (isLoading) {
    return (
      <div className="bg-slate-800/70 backdrop-blur-lg p-6 rounded-xl shadow-2xl border border-slate-700 min-h-[200px] flex flex-col justify-center items-center">
        <SpinnerIcon className="w-12 h-12 text-sky-400 mb-4" />
        <p className="text-slate-300 text-lg">Generating wisdom...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-slate-800/70 backdrop-blur-lg p-6 rounded-xl shadow-2xl border border-red-500/50 min-h-[200px]">
        <div className="flex items-center text-red-400 mb-3">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 mr-2">
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z" />
          </svg>
          <h3 className="text-xl font-semibold">An Error Occurred</h3>
        </div>
        <p className="text-red-300 whitespace-pre-wrap">{error}</p>
      </div>
    );
  }

  if (!content) {
    return (
      <div className="bg-slate-800/70 backdrop-blur-lg p-6 rounded-xl shadow-2xl border border-slate-700 min-h-[200px] flex flex-col justify-center items-center">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-12 h-12 text-slate-500 mb-4">
          <path strokeLinecap="round" strokeLinejoin="round" d="M12 18v-5.25m0 0a6.01 6.01 0 001.5-.189m-1.5.189a6.01 6.01 0 01-1.5-.189m3.75 7.478a12.06 12.06 0 01-4.5 0m3.75 2.354a15.054 15.054 0 01-4.5 0M12 18v-5.25m0 0a6.01 6.01 0 001.5-.189m-1.5.189a6.01 6.01 0 01-1.5-.189m3.75 7.478a12.06 12.06 0 01-4.5 0m3.75 2.354a15.054 15.054 0 01-4.5 0M9.75 11.25A2.25 2.25 0 0112 9m0 2.25c-.617 0-1.181.22-1.624.588M14.25 11.25a2.25 2.25 0 00-2.25-2.25M12 9A2.25 2.25 0 009.75 11.25m2.25-2.25c.617 0 1.181.22 1.624.588M12 6.75a2.25 2.25 0 110 4.5 2.25 2.25 0 010-4.5z" />
        </svg>
        <p className="text-slate-400 text-lg">Select your options and click "Generate Content".</p>
        <p className="text-slate-500 text-sm mt-1">Let the learning journey begin!</p>
      </div>
    );
  }

  return (
    <div className="bg-slate-800/70 backdrop-blur-lg p-6 rounded-xl shadow-2xl border border-slate-700 min-h-[200px]">
      <h3 className="text-xl font-semibold text-sky-400 mb-4">Generated Content:</h3>
      <div className="text-slate-200 whitespace-pre-wrap prose prose-invert max-w-none prose-p:my-2 prose-headings:my-3 prose-ul:my-2 prose-li:my-1">
        {content}
      </div>
    </div>
  );
};

export default ContentDisplay;
    