
import React from 'react';
import { Language, Country, LearningMode, SelectionOptions } from '../types';
import { AVAILABLE_LANGUAGES, AVAILABLE_COUNTRIES, AVAILABLE_MODES } from '../constants';
import LanguageIcon from './icons/LanguageIcon';
import GlobeIcon from './icons/GlobeIcon';
import BookOpenIcon from './icons/BookOpenIcon';
import SpinnerIcon from './icons/SpinnerIcon';

interface ControlPanelProps {
  selections: SelectionOptions;
  onSelectionChange: <K extends keyof SelectionOptions>(key: K, value: SelectionOptions[K]) => void;
  onGenerate: () => void;
  isLoading: boolean;
  apiKeyMissing: boolean;
}

const ControlPanel: React.FC<ControlPanelProps> = ({
  selections,
  onSelectionChange,
  onGenerate,
  isLoading,
  apiKeyMissing,
}) => {
  const SelectField = <T extends string>({
    id,
    label,
    value,
    options,
    onChange,
    icon,
  }: {
    id: string;
    label: string;
    value: T;
    options: T[];
    onChange: (event: React.ChangeEvent<HTMLSelectElement>) => void;
    icon: React.ReactNode;
  }) => (
    <div className="mb-4">
      <label htmlFor={id} className="flex items-center text-sm font-medium text-slate-300 mb-1">
        {icon}
        <span className="ml-2">{label}</span>
      </label>
      <select
        id={id}
        value={value}
        onChange={onChange}
        className="w-full p-3 bg-slate-700 border border-slate-600 rounded-lg text-slate-100 focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition-colors"
        disabled={isLoading || apiKeyMissing}
      >
        {options.map((option) => (
          <option key={option} value={option}>
            {option}
          </option>
        ))}
      </select>
    </div>
  );

  return (
    <div className="bg-slate-800/70 backdrop-blur-lg p-6 rounded-xl shadow-2xl border border-slate-700">
      <h2 className="text-2xl font-semibold text-sky-400 mb-6">Explore & Learn</h2>
      
      <SelectField
        id="language-select"
        label="Instruction Language"
        value={selections.language}
        options={AVAILABLE_LANGUAGES}
        onChange={(e) => onSelectionChange('language', e.target.value as Language)}
        icon={<LanguageIcon className="w-5 h-5 text-sky-400" />}
      />

      <SelectField
        id="country-select"
        label="Focus Country"
        value={selections.country}
        options={AVAILABLE_COUNTRIES}
        onChange={(e) => onSelectionChange('country', e.target.value as Country)}
        icon={<GlobeIcon className="w-5 h-5 text-sky-400" />}
      />

      <SelectField
        id="mode-select"
        label="Learning Mode"
        value={selections.mode}
        options={AVAILABLE_MODES}
        onChange={(e) => onSelectionChange('mode', e.target.value as LearningMode)}
        icon={<BookOpenIcon className="w-5 h-5 text-sky-400" />}
      />

      <button
        onClick={onGenerate}
        disabled={isLoading || apiKeyMissing}
        className={`w-full mt-4 flex items-center justify-center font-semibold py-3 px-4 rounded-lg shadow-md transition-all duration-150 ease-in-out
                    ${isLoading || apiKeyMissing 
                      ? 'bg-slate-600 text-slate-400 cursor-not-allowed' 
                      : 'bg-sky-500 hover:bg-sky-600 text-white focus:outline-none focus:ring-2 focus:ring-sky-400 focus:ring-opacity-75'}`}
      >
        {isLoading ? (
          <>
            <SpinnerIcon className="w-5 h-5 mr-2" />
            Generating...
          </>
        ) : (
          '✨ Generate Content'
        )}
      </button>
    </div>
  );
};

export default ControlPanel;
    