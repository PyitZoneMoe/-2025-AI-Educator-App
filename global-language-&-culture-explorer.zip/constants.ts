
import { Country, Language, LearningMode } from './types';

export const GEMINI_MODEL_NAME = 'gemini-2.5-flash-preview-04-17';

export const AVAILABLE_LANGUAGES: Language[] = [
  Language.ENGLISH,
  Language.MYANMAR,
];

export const AVAILABLE_COUNTRIES: Country[] = [
  Country.SOUTH_KOREA,
  Country.JAPAN,
  Country.CHINA,
];

export const AVAILABLE_MODES: LearningMode[] = [
  LearningMode.FACTS,
  LearningMode.PHRASES,
  LearningMode.CULTURE,
  LearningMode.QUIZ,
];

export const API_KEY_ERROR_MESSAGE = "API_KEY environment variable not found. Please set it up to use the AI features.";
    