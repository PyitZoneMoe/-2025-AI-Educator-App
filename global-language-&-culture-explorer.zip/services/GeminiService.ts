
import { GoogleGenAI } from "@google/genai";
import { GEMINI_MODEL_NAME } from '../constants';

const getApiKey = (): string | undefined => {
  // In a real browser environment, process.env might not be directly available
  // unless specific bundler configurations are used (like Vite's import.meta.env).
  // For this example, we'll try to access it, but a robust solution would handle this better
  // or expect it to be globally defined by the execution environment.
  // For the purpose of this exercise, we directly reference `process.env.API_KEY`.
  // In a real deployment scenario, this needs to be handled according to the environment.
  return process.env.API_KEY;
};


export const generateEducationalContent = async (prompt: string): Promise<string> => {
  const apiKey = getApiKey();
  if (!apiKey) {
    throw new Error("API_KEY is not configured. Please ensure the API_KEY environment variable is set.");
  }

  const ai = new GoogleGenAI({ apiKey });

  try {
    const response = await ai.models.generateContent({
      model: GEMINI_MODEL_NAME,
      contents: [{ role: "user", parts: [{ text: prompt }] }],
       // No thinkingConfig for general educational content for now, to ensure higher quality by default.
       // If low latency is critical for a specific mode (like a fast quiz), it could be added here conditionally.
    });
    return response.text;
  } catch (error) {
    console.error("Error generating content from Gemini API:", error);
    if (error instanceof Error) {
      return `Error from AI: ${error.message}`;
    }
    return "An unknown error occurred while fetching data from the AI.";
  }
};
    