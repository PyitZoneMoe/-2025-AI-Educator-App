
export enum Language {
  ENGLISH = 'English',
  MYANMAR = 'Myanmar',
}

export enum Country {
  SOUTH_KOREA = 'South Korea',
  JAPAN = 'Japan',
  CHINA = 'China',
}

export enum LearningMode {
  FACTS = 'Interesting Facts',
  PHRASES = 'Common Phrases',
  CULTURE = 'Cultural Highlights',
  QUIZ = 'Quick Quiz',
}

export interface SelectionOptions {
  language: Language;
  country: Country;
  mode: LearningMode;
}
    